---
title: Hack.init()+重庆科学营
date: 2017-07-07 01:06:42
tags: 活动
categories: 活动

---

![3239776488D4A9377DC6B070C498BCF4.jpg](http://upload-images.jianshu.io/upload_images/2218072-45631e578f1ebdba.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
Hack.init()+重庆科学营 日程记录

<!-- more -->

# July 6th

![IMG_20170706_175331_HDR-01.jpeg](http://upload-images.jianshu.io/upload_images/2218072-5cb0d1f2b8b32f3c.jpeg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

下午5点坐滴滴来到机场，发现航班取消了(到机场才收到通知)。。。
那就改签吧，居然赶上提前的航班
想想也是幸运，飞机上剩下最后的3个位子，刚好被我们订到，当然只能是最后一排。。。
于是，就上飞机了~

![IMG_20170707_003441.jpg](http://upload-images.jianshu.io/upload_images/2218072-f4d9631536a5f4fc.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

中间多了个舟山经停：

![IMG_20170706_210351_HHT-01.jpeg](http://upload-images.jianshu.io/upload_images/2218072-1b8e102033508fdf.jpeg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

3个小时后，终于到上海了。。。
加上等待的时间，飞机的速度可能还不如高铁。

上海到了 pupose~

![3239776488D4A9377DC6B070C498BCF4.jpg](http://upload-images.jianshu.io/upload_images/2218072-b820ac9dde2ff32b.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
只不过，航班改签把着陆的机场也改了
原来订的青年旅馆只能作废，改订浦东机场旁边的锦江之星
还好酒店有免费的接机。。。

第0天还是挺顺利的，可以用`歪打正着`来形容，只不过多花了点钱而已~

---
# July 7th
第1天，
早上早早地来到市中心的酒店放行李，然后就赶往复旦
35°的天气，天气预报是高温黄色预警，我们到复旦后发现哪里都进不去，于是就。。。拍了张照就走了
